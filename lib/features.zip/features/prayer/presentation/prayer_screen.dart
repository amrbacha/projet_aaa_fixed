import 'dart:async';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:projet_aaa_fixed/core/models/quran_data.dart';
import 'package:projet_aaa_fixed/core/providers/audio_provider.dart';
import 'package:projet_aaa_fixed/core/providers/theme_provider.dart';
import 'package:projet_aaa_fixed/core/services/assistant_service.dart';
import 'package:projet_aaa_fixed/core/services/camera_utils.dart';
import 'package:projet_aaa_fixed/core/services/local_storage_service.dart';
import 'package:projet_aaa_fixed/core/services/pose_detection_service.dart';
import 'package:projet_aaa_fixed/core/services/quran_service.dart';
import 'package:projet_aaa_fixed/core/services/windowed_wird_recitation_engine.dart' as wird_matcher;
import 'package:projet_aaa_fixed/features/prayer_session/controllers/prayer_session_controller.dart';
import 'package:projet_aaa_fixed/features/prayer_session/services/smart_prayer_engine.dart';
import 'package:projet_aaa_fixed/widgets/islamic_background.dart';

import '../../../l10n/app_localizations.dart';

class PrayerFlowStep {
  final String title;
  final String? content;
  final String? surahName;
  final int? ayahNumber;
  final int rakahNumber;
  final bool isRecitation;
  final int? surahNumber;
  final bool isAction;
  final PrayerPosition expectedPosition;
  final int repetitionCount;
  final Duration pauseAfter;
  final int? wirdIndex;

  PrayerFlowStep(
    this.title,
    this.rakahNumber, {
    this.content,
    this.surahName,
    this.ayahNumber,
    this.isRecitation = false,
    this.surahNumber,
    this.isAction = false,
    this.expectedPosition = PrayerPosition.standing,
    this.repetitionCount = 1,
    this.pauseAfter = const Duration(milliseconds: 1000),
    this.wirdIndex,
  });
}

class _SimplePoseDebug {
  final String instruction;
  final int quality;

  const _SimplePoseDebug({
    required this.instruction,
    required this.quality,
  });
}

class PrayerScreen extends StatefulWidget {
  final String prayerName;
  final List<Ayah> wird;

  const PrayerScreen({
    super.key,
    required this.prayerName,
    required this.wird,
  });

  @override
  State<PrayerScreen> createState() => _PrayerScreenState();
}

class _PrayerScreenState extends State<PrayerScreen> {
  int _currentStepIndex = 0;
  List<PrayerFlowStep> _fullPrayerFlow = [];

  bool _isLoading = true;
  bool _isCalibrating = true;
  bool _prayerStarted = false;
  bool _isExecutingStep = false;

  late bool _isCameraEnabled;
  bool _isAnisListening = true;
  bool _isQariAudioEnabled = true;

  double _qariSpeed = 1.0;
  double _transitionSpeedFactor = 1.0;

  CameraController? _cameraController;
  final PoseDetectionService _poseService = PoseDetectionService();
  final AssistantService _anis = AssistantService();
  final QuranService _quranService = QuranService();

  bool _isCameraReady = false;
  PoseVisibility? _lastVisibility;
  PrayerPosition _liveDetectedPosition = PrayerPosition.unknown;
  PrayerPosition _lastStableCandidate = PrayerPosition.unknown;
  int _stablePoseFrames = 0;

  bool _isListeningForUser = false;
  String _lastRecognizedText = '';
  String _matchStatus = '';

  PrayerSessionController? _sessionController;
  SmartPrayerEngine? _smartPrayerEngine;

  static const int _requiredStablePoseFrames = 4;
  static const int _maxVerseRetries = 2;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadAllResources());
  }

  Future<void> _loadAllResources() async {
    final settings = Provider.of<ThemeProvider>(context, listen: false).settings;
    final l10n = AppLocalizations.of(context);

    _isCameraEnabled = settings.isCameraOn;
    _isCalibrating = _isCameraEnabled;

    final allVerses = await _quranService.getAllVerses(excludeFatiha: false);
    final fatihaVerses = allVerses.where((a) => a.surahNumber == 1).toList();

    if (l10n != null) {
      _fullPrayerFlow = _buildFullPrayerFlow(
        widget.prayerName,
        widget.wird,
        fatihaVerses,
        l10n,
      );
    }

    if (_isCameraEnabled) {
      await _initCamera();
    }

    if (_isCalibrating) {
      await _anis.speakPositionGuidance('start_prompt');
    } else {
      await _startPrayer();
    }

    if (mounted) {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _initCamera() async {
    try {
      final cameras = await availableCameras();
      if (cameras.isEmpty) return;

      final front = cameras.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.front,
        orElse: () => cameras.first,
      );

      _cameraController = CameraController(
        front,
        ResolutionPreset.medium,
        enableAudio: false,
        imageFormatGroup: ImageFormatGroup.yuv420,
      );

      await _cameraController!.initialize();

      await _cameraController!.startImageStream((image) async {
        if (!_isCameraEnabled || !mounted) return;

        final inputImage = CameraUtils.inputImageFromCameraImage(image, front);
        if (inputImage == null) return;

        final visibility = await _poseService.analyzePose(inputImage);
        if (!mounted) return;

        setState(() {
          _lastVisibility = visibility;
          _liveDetectedPosition = visibility.position;
        });

        _updateStablePose(visibility.position);

        if (!_prayerStarted && visibility.position == PrayerPosition.takbir) {
          await _startPrayer();
          return;
        }

        if (_prayerStarted && _stablePoseFrames >= _requiredStablePoseFrames) {
          _smartPrayerEngine?.markPoseMatched();
          _trySmartAdvance();
        }
      });

      if (mounted) {
        setState(() => _isCameraReady = true);
      }
    } catch (e) {
      debugPrint('Camera Error: $e');
    }
  }

  void _updateStablePose(PrayerPosition position) {
    if (position == _lastStableCandidate) {
      _stablePoseFrames++;
    } else {
      _lastStableCandidate = position;
      _stablePoseFrames = 1;
    }
  }

  Future<void> _startPrayer() async {
    if (_prayerStarted) return;

    if (mounted) {
      setState(() {
        _isCalibrating = false;
        _prayerStarted = true;
        _matchStatus = 'بدأت الصلاة';
      });
    }

    _sessionController = PrayerSessionController();
    _sessionController!.initialize(
      cameraEnabled: _isCameraEnabled,
      micEnabled: _isAnisListening,
    );

    _smartPrayerEngine = SmartPrayerEngine(
      controller: _sessionController!,
    );

    final audio = Provider.of<AudioProvider>(context, listen: false);
    await audio.setPlaybackRate(_qariSpeed);

    final l10n = AppLocalizations.of(context)!;
    await _anis.speak(l10n.prayerStartConfirm);
    await Future.delayed(const Duration(milliseconds: 700));

    await _executeCurrentStep();
  }

  Future<void> _executeCurrentStep() async {
    if (!_prayerStarted || _isExecutingStep) return;
    if (_currentStepIndex >= _fullPrayerFlow.length) return;

    _isExecutingStep = true;
    await _smartPrayerEngine?.stopListening();

    if (mounted) {
      setState(() {
        _isListeningForUser = false;
        _lastRecognizedText = '';
      });
    }

    final step = _fullPrayerFlow[_currentStepIndex];
    final audio = Provider.of<AudioProvider>(context, listen: false);

    _smartPrayerEngine?.beginStep(
      step: step,
      fallbackDuration: Duration(
        milliseconds: ((step.pauseAfter.inMilliseconds + 2500) / _transitionSpeedFactor).toInt(),
      ),
    );

    if (!_isCameraEnabled && !_isAnisListening) {
      await _executeTimedStep(step, audio);
    } else if (step.isRecitation && step.wirdIndex != null) {
      await _executeWirdRecitationStep(step, audio, retryCount: 0);
    } else if (step.isRecitation) {
      await _executeGenericRecitationStep(step, audio);
    } else {
      await _executeActionStep(step, audio);
    }

    _isExecutingStep = false;
  }

  Future<void> _executeTimedStep(PrayerFlowStep step, AudioProvider audio) async {
    if (_isQariAudioEnabled) {
      if (step.isRecitation && step.surahNumber != null && step.ayahNumber != null) {
        await audio.playVerse(step.surahNumber!, step.ayahNumber!);
        await audio.onPlayerComplete.first;
      } else if (step.content != null && step.content!.isNotEmpty) {
        for (int i = 0; i < step.repetitionCount; i++) {
          await audio.speakActionAndWait(step.content!);
        }
      }
    } else {
      await Future.delayed(step.pauseAfter);
    }

    _smartPrayerEngine?.markQariFinished();
    _trySmartAdvance(forceFallbackIfNeeded: true);
  }

  Future<void> _executeGenericRecitationStep(PrayerFlowStep step, AudioProvider audio) async {
    if (_isQariAudioEnabled && step.surahNumber != null && step.ayahNumber != null) {
      await audio.playVerse(step.surahNumber!, step.ayahNumber!);
      await audio.onPlayerComplete.first;
    } else {
      await Future.delayed(Duration(milliseconds: (1800 / _qariSpeed).toInt()));
    }

    _smartPrayerEngine?.markQariFinished();
    _trySmartAdvance(forceFallbackIfNeeded: true);
  }

  Future<void> _executeWirdRecitationStep(
    PrayerFlowStep step,
    AudioProvider audio, {
    required int retryCount,
  }) async {
    if (step.wirdIndex == null || _smartPrayerEngine == null) {
      await _executeGenericRecitationStep(step, audio);
      return;
    }

    bool shouldRetry = false;

    if (_isAnisListening) {
      await _smartPrayerEngine!.startWirdListening(
        wird: widget.wird,
        wirdIndex: step.wirdIndex!,
        onDecision: (text, decision) {
          if (!mounted) return;

          setState(() {
            _isListeningForUser = true;
            _lastRecognizedText = text;
            _matchStatus = decision.reason;
          });

          if (decision.type == wird_matcher.WirdRecitationDecisionType.retryCurrentAyah) {
            shouldRetry = true;
          }

          _trySmartAdvance();
        },
      );
    }

    if (_isQariAudioEnabled && step.surahNumber != null && step.ayahNumber != null) {
      await audio.playVerse(step.surahNumber!, step.ayahNumber!);
      await audio.onPlayerComplete.first;
    } else {
      await Future.delayed(Duration(milliseconds: (1800 / _qariSpeed).toInt()));
    }

    _smartPrayerEngine!.markQariFinished();
    _trySmartAdvance();

    await Future.delayed(const Duration(milliseconds: 700));

    final result = _smartPrayerEngine!.evaluate(
      step: step,
      cameraEnabled: _isCameraEnabled,
      micEnabled: _isAnisListening,
    );

    if (!result.shouldAdvance && shouldRetry && retryCount < _maxVerseRetries) {
      if (mounted) {
        setState(() {
          _matchStatus = 'أعد الآية الحالية من الورد للتصحيح';
        });
      }
      await _smartPrayerEngine!.stopListening();
      await Future.delayed(const Duration(milliseconds: 250));
      await _executeWirdRecitationStep(step, audio, retryCount: retryCount + 1);
      return;
    }

    if (!result.shouldAdvance) {
      _smartPrayerEngine!.applyAdvanceReason(SmartAdvanceReason.timedFallback);
      _advanceToNextStep();
    }
  }

  Future<void> _executeActionStep(PrayerFlowStep step, AudioProvider audio) async {
    if (_isQariAudioEnabled && step.content != null && step.content!.isNotEmpty) {
      for (int i = 0; i < step.repetitionCount; i++) {
        await audio.speakActionAndWait(step.content!);
        await Future.delayed(Duration(milliseconds: (700 / _transitionSpeedFactor).toInt()));
      }
    } else {
      await Future.delayed(step.pauseAfter);
    }

    _smartPrayerEngine?.markQariFinished();
    _trySmartAdvance();

    if (!_isCameraEnabled || step.expectedPosition == PrayerPosition.standing) {
      await Future.delayed(const Duration(milliseconds: 300));
      _trySmartAdvance(forceFallbackIfNeeded: true);
    }
  }

  void _trySmartAdvance({bool forceFallbackIfNeeded = false}) {
    if (_smartPrayerEngine == null || _currentStepIndex >= _fullPrayerFlow.length) return;

    final step = _fullPrayerFlow[_currentStepIndex];
    final result = _smartPrayerEngine!.evaluate(
      step: step,
      cameraEnabled: _isCameraEnabled,
      micEnabled: _isAnisListening,
    );

    if (mounted) {
      setState(() {
        _matchStatus = result.message;
      });
    }

    if (result.shouldAdvance && result.reason != null) {
      _smartPrayerEngine!.applyAdvanceReason(result.reason!);
      _advanceToNextStep();
      return;
    }

    if (forceFallbackIfNeeded) {
      _smartPrayerEngine!.applyAdvanceReason(SmartAdvanceReason.timedFallback);
      _advanceToNextStep();
    }
  }

  void _advanceToNextStep() {
    if (!mounted || !_prayerStarted) return;

    if (_currentStepIndex < _fullPrayerFlow.length - 1) {
      setState(() {
        _currentStepIndex++;
        _isListeningForUser = false;
        _lastRecognizedText = '';
        _stablePoseFrames = 0;
      });
      unawaited(_executeCurrentStep());
    } else {
      unawaited(_finishPrayer());
    }
  }

  Future<void> _finishPrayer() async {
    await LocalStorageService.markPrayerAsCompleted(widget.prayerName);
    await _smartPrayerEngine?.dispose();
    await _anis.speak('تقبل الله طاعتك. تم إكمال الصلاة بنجاح.');
    if (mounted) context.pop();
  }

  String _positionLabel(PrayerPosition position) {
    switch (position) {
      case PrayerPosition.standing:
        return 'القيام';
      case PrayerPosition.ruku:
        return 'الركوع';
      case PrayerPosition.sujud:
        return 'السجود';
      case PrayerPosition.sitting:
        return 'الجلسة';
      case PrayerPosition.takbir:
        return 'تكبيرة الإحرام';
      case PrayerPosition.unknown:
        return 'غير واضحة';
    }
  }

  _SimplePoseDebug _poseDebug() {
    if (_lastVisibility == null) {
      return const _SimplePoseDebug(
        instruction: 'اضبط تمركزك داخل الإطار واستعد لتكبيرة الإحرام',
        quality: 0,
      );
    }

    final pos = _lastVisibility!.position;

    switch (pos) {
      case PrayerPosition.takbir:
        return const _SimplePoseDebug(
          instruction: 'الوضعية مناسبة ويمكن البدء',
          quality: 92,
        );
      case PrayerPosition.standing:
        return const _SimplePoseDebug(
          instruction: 'تم التعرف على القيام بشكل جيد',
          quality: 88,
        );
      case PrayerPosition.ruku:
        return const _SimplePoseDebug(
          instruction: 'تم التعرف على الركوع',
          quality: 86,
        );
      case PrayerPosition.sujud:
        return const _SimplePoseDebug(
          instruction: 'تم التعرف على السجود',
          quality: 86,
        );
      case PrayerPosition.sitting:
        return const _SimplePoseDebug(
          instruction: 'تم التعرف على الجلسة',
          quality: 84,
        );
      case PrayerPosition.unknown:
        return const _SimplePoseDebug(
          instruction: 'قف داخل الإطار ليظهر تتبع الحركة بوضوح',
          quality: 35,
        );
    }
  }

  @override
  void dispose() {
    _cameraController?.dispose();
    _poseService.dispose();
    _smartPrayerEngine?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        backgroundColor: Color(0xFF0D3B2E),
        body: Center(child: CircularProgressIndicator(color: Color(0xFFF5A623))),
      );
    }

    final l10n = AppLocalizations.of(context)!;
    final step = _fullPrayerFlow[_currentStepIndex];

    return IslamicBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          backgroundColor: Colors.black45,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.close, color: Colors.white70),
            onPressed: () => context.pop(),
          ),
          title: Text(
            _isCalibrating ? 'تحديد الوضعية والسرعة' : step.title,
            style: GoogleFonts.amiri(
              color: const Color(0xFFF5A623),
              fontWeight: FontWeight.bold,
            ),
          ),
          centerTitle: true,
        ),
        body: _isCalibrating ? _buildCalibrationUI(l10n) : _buildPrayerUI(step),
      ),
    );
  }

  Widget _buildCalibrationUI(AppLocalizations l10n) {
    return SingleChildScrollView(
      child: Column(
        children: [
          const SizedBox(height: 15),
          _buildQuickSettingsPanel(),
          const SizedBox(height: 15),
          _buildSpeedSettingsPanel(),
          const SizedBox(height: 20),
          Center(
            child: Container(
              width: MediaQuery.of(context).size.width * 0.85,
              height: MediaQuery.of(context).size.height * 0.35,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                border: Border.all(color: const Color(0xFFF5A623), width: 3),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(27),
                child: _buildCameraPanel(),
              ),
            ),
          ),
          const SizedBox(height: 18),
          if (_lastVisibility != null) _buildPoseGuidanceCard(),
          const SizedBox(height: 18),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFF5A623),
              padding: const EdgeInsets.symmetric(horizontal: 60, vertical: 18),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(35)),
            ),
            onPressed: _startPrayer,
            icon: const Icon(Icons.play_arrow_rounded, color: Colors.black, size: 30),
            label: Text(
              'ابدأ الصلاة الآن',
              style: GoogleFonts.amiri(
                color: Colors.black,
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(height: 30),
        ],
      ),
    );
  }

  Widget _buildPrayerUI(PrayerFlowStep step) {
    return Column(
      children: [
        const SizedBox(height: 12),
        if (_isCameraEnabled)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: SizedBox(
              height: 155,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(22),
                child: _buildCameraPanel(),
              ),
            ),
          ),
        if (_isCameraEnabled) const SizedBox(height: 14),
        if (step.isRecitation && step.surahName != null)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            decoration: BoxDecoration(
              color: const Color(0xFFF5A623).withOpacity(0.15),
              borderRadius: BorderRadius.circular(15),
              border: Border.all(color: const Color(0xFFF5A623).withOpacity(0.3)),
            ),
            child: Text(
              '${step.surahName} - آية ${step.ayahNumber}',
              style: GoogleFonts.amiri(
                color: const Color(0xFFF5A623),
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        const SizedBox(height: 16),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 30),
            child: Center(
              child: SingleChildScrollView(
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 500),
                  child: Text(
                    step.content ?? '',
                    key: ValueKey(step.content),
                    textAlign: TextAlign.center,
                    style: GoogleFonts.amiri(
                      color: Colors.white,
                      fontSize: 32,
                      height: 1.8,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
        _buildStatusCard(step),
        if (_isListeningForUser) _buildSmartCorrectorUI(),
        _buildBottomControls(),
        const SizedBox(height: 40),
      ],
    );
  }

  Widget _buildCameraPanel() {
    if (!_isCameraReady || _cameraController == null) {
      return Container(
        color: Colors.black87,
        child: Center(
          child: Text(
            'الكاميرا غير جاهزة',
            style: GoogleFonts.amiri(color: Colors.white70),
          ),
        ),
      );
    }

    return Stack(
      fit: StackFit.expand,
      children: [
        CameraPreview(_cameraController!),
        Container(
          decoration: BoxDecoration(
            border: Border.all(
              color: const Color(0xFF4DFF88).withOpacity(0.85),
              width: 2,
            ),
          ),
        ),
        Positioned(
          left: 10,
          right: 10,
          bottom: 10,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.black54,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: const Color(0xFF4DFF88).withOpacity(0.4),
              ),
            ),
            child: Text(
              'الوضعية الحالية: ${_positionLabel(_liveDetectedPosition)}',
              textAlign: TextAlign.center,
              style: GoogleFonts.amiri(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildPoseGuidanceCard() {
    final debug = _poseDebug();
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.black38,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFFF5A623).withOpacity(0.35)),
      ),
      child: Column(
        children: [
          Text(
            'جودة المطابقة: %${debug.quality}',
            style: GoogleFonts.amiri(
              color: const Color(0xFFF5A623),
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            debug.instruction,
            textAlign: TextAlign.center,
            style: GoogleFonts.amiri(color: Colors.white70, fontSize: 15),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickSettingsPanel() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.black38,
        borderRadius: BorderRadius.circular(25),
        border: Border.all(color: Colors.white10),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildToggleItem(
            icon: _isAnisListening ? Icons.mic : Icons.mic_off,
            label: 'أنيس',
            value: _isAnisListening,
            onTap: () => setState(() => _isAnisListening = !_isAnisListening),
          ),
          _buildToggleItem(
            icon: _isQariAudioEnabled ? Icons.volume_up : Icons.volume_off,
            label: 'المقرئ',
            value: _isQariAudioEnabled,
            onTap: () => setState(() => _isQariAudioEnabled = !_isQariAudioEnabled),
          ),
          _buildToggleItem(
            icon: _isCameraEnabled ? Icons.videocam : Icons.videocam_off,
            label: 'الكاميرا',
            value: _isCameraEnabled,
            onTap: () {
              setState(() => _isCameraEnabled = !_isCameraEnabled);
              if (_isCameraEnabled) {
                _initCamera();
              } else {
                _cameraController?.dispose();
                _cameraController = null;
                _isCameraReady = false;
              }
            },
          ),
        ],
      ),
    );
  }

  Widget _buildSpeedSettingsPanel() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(25),
        border: Border.all(color: Colors.white10),
      ),
      child: Column(
        children: [
          _buildSpeedSlider('سرعة تلاوة المقرئ', _qariSpeed, 0.75, 1.25, (v) => setState(() => _qariSpeed = v)),
          const Divider(color: Colors.white10, height: 25),
          _buildSpeedSlider('سرعة انتقال الأركان', _transitionSpeedFactor, 0.75, 1.5, (v) => setState(() => _transitionSpeedFactor = v)),
        ],
      ),
    );
  }

  Widget _buildSpeedSlider(String label, double value, double min, double max, Function(double) onChanged) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: GoogleFonts.amiri(color: Colors.white70, fontSize: 14)),
            Text(
              value == 1.0 ? 'طبيعي' : value > 1.0 ? 'سريع' : 'هادئ',
              style: GoogleFonts.amiri(color: const Color(0xFFF5A623), fontSize: 12),
            ),
          ],
        ),
        Slider(
          value: value,
          min: min,
          max: max,
          divisions: 4,
          activeColor: const Color(0xFFF5A623),
          inactiveColor: Colors.white10,
          onChanged: onChanged,
        ),
      ],
    );
  }

  Widget _buildToggleItem({
    required IconData icon,
    required String label,
    required bool value,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: value ? const Color(0xFFF5A623).withOpacity(0.2) : Colors.white10,
              border: Border.all(color: value ? const Color(0xFFF5A623) : Colors.transparent),
            ),
            child: Icon(icon, color: value ? const Color(0xFFF5A623) : Colors.white60, size: 24),
          ),
          const SizedBox(height: 5),
          Text(label, style: GoogleFonts.amiri(color: Colors.white70, fontSize: 11)),
        ],
      ),
    );
  }

  Widget _buildStatusCard(PrayerFlowStep step) {
    final sessionStatus = _sessionController?.status ?? 'متابعة الصلاة';
    return Container(
      margin: const EdgeInsets.only(bottom: 14, left: 20, right: 20),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFF5A623).withOpacity(0.25)),
      ),
      child: Row(
        children: [
          const Icon(Icons.sync_alt_rounded, color: Color(0xFFF5A623), size: 18),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              _matchStatus.isNotEmpty ? _matchStatus : sessionStatus,
              textAlign: TextAlign.right,
              style: GoogleFonts.amiri(color: Colors.white70, fontSize: 14),
            ),
          ),
          const SizedBox(width: 10),
          Text(
            step.title,
            style: GoogleFonts.amiri(
              color: const Color(0xFFF5A623),
              fontSize: 15,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSmartCorrectorUI() {
    return Container(
      margin: const EdgeInsets.only(bottom: 20, left: 20, right: 20),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.redAccent.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.redAccent.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          const Icon(Icons.mic, color: Colors.redAccent, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              _lastRecognizedText.isEmpty ? 'أكمل التلاوة بصوتك...' : _lastRecognizedText,
              style: GoogleFonts.amiri(color: Colors.white70, fontSize: 16),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomControls() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _buildControlBtn(
          _isQariAudioEnabled ? Icons.volume_up : Icons.volume_off,
          () => setState(() => _isQariAudioEnabled = !_isQariAudioEnabled),
        ),
        const SizedBox(width: 25),
        FloatingActionButton(
          backgroundColor: const Color(0xFFF5A623),
          child: const Icon(Icons.skip_next, color: Colors.black, size: 30),
          onPressed: () {
            _smartPrayerEngine?.requestManualAdvance();
            _trySmartAdvance(forceFallbackIfNeeded: true);
          },
        ),
        const SizedBox(width: 25),
        _buildControlBtn(
          _isCameraEnabled ? Icons.videocam : Icons.videocam_off,
          () {
            setState(() => _isCameraEnabled = !_isCameraEnabled);
            if (_isCameraEnabled) {
              _initCamera();
            }
          },
        ),
      ],
    );
  }

  Widget _buildControlBtn(IconData icon, VoidCallback onTap) {
    return IconButton(icon: Icon(icon, color: Colors.white70, size: 28), onPressed: onTap);
  }

  List<PrayerFlowStep> _buildFullPrayerFlow(
    String prayerName,
    List<Ayah> wird,
    List<Ayah> fatiha,
    AppLocalizations l10n,
  ) {
    final List<PrayerFlowStep> flow = [];
    final name = prayerName.toLowerCase();

    final int totalRakahs = (name.contains('fajr') || name.contains('فجر'))
        ? 2
        : (name.contains('maghrib') || name.contains('مغرب'))
            ? 3
            : 4;

    final List<Ayah> firstRakahWird =
        wird.isEmpty ? <Ayah>[] : wird.sublist(0, (wird.length / 2).ceil());
    final List<Ayah> secondRakahWird =
        wird.isEmpty ? <Ayah>[] : wird.sublist((wird.length / 2).ceil());

    for (int r = 1; r <= totalRakahs; r++) {
      flow.add(PrayerFlowStep(
        r == 1 ? 'تكبيرة الإحرام' : 'تكبيرة القيام',
        r,
        content: 'اللَّهُ أَكْبَرُ',
        isAction: true,
      ));

      if (r == 1) {
        flow.add(PrayerFlowStep(
          l10n.istiftahDua,
          r,
          content:
              'سُبْحَانَكَ اللَّهُمَّ وَبِحَمْدِكَ، وَتَبَارَكَ اسْمُكَ، وَتَعَالَى جَدُّكَ، وَلَا إِلَهَ غَيْرُكَ',
          isAction: true,
        ));
        flow.add(PrayerFlowStep(
          'الاستعاذة',
          r,
          content: 'أَعُوذُ بِاللَّهِ مِنَ الشَّيْطَانِ الرَّجِيمِ',
          isAction: true,
        ));
      }

      flow.add(PrayerFlowStep(
        'البسملة',
        r,
        content: 'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ',
        isAction: true,
      ));

      for (final f in fatiha) {
        flow.add(PrayerFlowStep(
          'سورة الفاتحة',
          r,
          content: f.text,
          surahName: 'سورة الفاتحة',
          ayahNumber: f.ayahNumber,
          isRecitation: true,
          surahNumber: 1,
        ));
      }

      flow.add(PrayerFlowStep(
        l10n.amin,
        r,
        content: 'آمِين',
        isAction: true,
      ));

      final List<Ayah> rakahWird = r == 1 ? firstRakahWird : secondRakahWird;

      if (r <= 2 && rakahWird.isNotEmpty) {
        flow.add(PrayerFlowStep(
          'البسملة',
          r,
          content: 'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ',
          isAction: true,
        ));

        for (final a in rakahWird) {
          flow.add(PrayerFlowStep(
            'تلاوة الورد',
            r,
            content: a.text,
            surahName: a.surahName,
            ayahNumber: a.ayahNumber,
            isRecitation: true,
            surahNumber: a.surahNumber,
            wirdIndex: wird.indexOf(a),
          ));
        }
      }

      flow.add(PrayerFlowStep(
        'التكبير للركوع',
        r,
        content: 'اللَّهُ أَكْبَرُ',
        isAction: true,
      ));
      flow.add(PrayerFlowStep(
        l10n.rukuLabel,
        r,
        content: 'سُبْحَانَ رَبِّيَ الْعَظِيمِ',
        isAction: true,
        expectedPosition: PrayerPosition.ruku,
        repetitionCount: 3,
      ));
      flow.add(PrayerFlowStep(
        'الرفع من الركوع',
        r,
        content: 'سَمِعَ اللَّهُ لِمَنْ حَمِدَهُ',
        isAction: true,
      ));
      flow.add(PrayerFlowStep(
        'التحميد',
        r,
        content: 'رَبَّنَا وَلَكَ الْحَمْدُ',
        isAction: true,
        pauseAfter: const Duration(milliseconds: 1500),
      ));
      flow.add(PrayerFlowStep(
        'التكبير للسجود',
        r,
        content: 'اللَّهُ أَكْبَرُ',
        isAction: true,
      ));
      flow.add(PrayerFlowStep(
        l10n.sujud1Label,
        r,
        content: 'سُبْحَانَ رَبِّيَ الْأَعْلَى',
        isAction: true,
        expectedPosition: PrayerPosition.sujud,
        repetitionCount: 3,
      ));
      flow.add(PrayerFlowStep(
        'التكبير للجلوس',
        r,
        content: 'اللَّهُ أَكْبَرُ',
        isAction: true,
      ));
      flow.add(PrayerFlowStep(
        l10n.sittingLabel,
        r,
        content: 'رَبِّ اغْفِرْ لِي. رَبِّ اغْفِرْ لِي',
        isAction: true,
        expectedPosition: PrayerPosition.sitting,
      ));
      flow.add(PrayerFlowStep(
        'التكبير للسجود',
        r,
        content: 'اللَّهُ أَكْبَرُ',
        isAction: true,
      ));
      flow.add(PrayerFlowStep(
        l10n.sujud2Label,
        r,
        content: 'سُبْحَانَ رَبِّيَ الْأَعْلَى',
        isAction: true,
        expectedPosition: PrayerPosition.sujud,
        repetitionCount: 3,
      ));
    }

    return flow;
  }
}
